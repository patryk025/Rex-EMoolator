# AidemMediaScriptsInterpreter
Prototyp modułu lexera oraz interpretera skryptów z gier Aidem Media wykorzystujących silnik PikLib oraz Bloomoo.
