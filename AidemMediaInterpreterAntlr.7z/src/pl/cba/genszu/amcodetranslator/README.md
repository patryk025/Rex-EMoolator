# AidemMediaScriptsInterpreter
Prototyp modułu lexera oraz interpretera skryptów z gier Aidem Media wykorzystujących silnik PikLib oraz Bloomoo.

Tu jest to samo co w branchu antlr_idea, dla środowiska AIDE na Androida.

